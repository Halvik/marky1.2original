const { MessageEmbed } = require("discord.js");



	function error(channel, content) {
		const embed = new MessageEmbed()
			.setAuthor("Błąd", "https://cdn.discordapp.com/emojis/784036532738719767.gif?v=1")
			.setDescription(content)
			.setColor("FF0000");
		channel.send(embed);
	}



module.exports = error
