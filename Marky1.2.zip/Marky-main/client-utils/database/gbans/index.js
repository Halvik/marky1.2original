// Thank you for using quick.db!
// This is an open-sourced better-sqlite3 wrapped designed to be easy to setup & utilize.

// We have an official verified Discord!
// https://discord.gg/plexidev

module.exports = require('./bin/handler.js')

// Looking for tutorials?
// We have some coming soon @ youtube.com/c/TrueXPixels, subscribe to stay notified!

// Documentation:
// https://quickdb.js.org