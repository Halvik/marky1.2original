const {MessageEmbed} = require("discord.js");

module.exports = {
	name: "help",
	aliases: ["pomoc"],

	run: async (client, message, args) => {

		const embed = new MessageEmbed()

	.setTitle("Pomoc")
			.setColor(0x00AE86)
			.setDescription("Dostępne komendy:\n\`,help\` - wyświetla listę komend \n\`,kanal #kanal\` - ustawia kanał reklam \n\`,reklama (reklama serwera)\` - ustawia reklame serwera\n \`,link\` - link do zaproszenia bota\n \`,info\` - informacje o reklamie")
		message.channel.send({embed})
	}
}
