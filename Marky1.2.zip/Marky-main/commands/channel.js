const {MessageEmbed} = require("discord.js");
module.exports = {
	name: "kanal",
	aliases: ["ustawkanal", "k"],
	run: async (client, message, args) => {
		if (!message.member.hasPermission("MANAGE_GUILD")) {
			return error(message.channel,"Nie posiadasz permisji Zarządzenie Serwerem!")
		}

		if(!args[0]) {
			return error(message.channel, "Podaj id lub oznacz kanal na ktorym maja byc wysylane reklamy!")
		}

		const channel = message.guild.channels.cache.get(args[0]) ||
			message.mentions.channels.first();
		if(!channel) {
			return error(message.channel, "Podany kanał nie istnieje, Podaj prawidłowe id lub oznacz kanał na który chcesz aby bot wysyłał reklamy!")
		}
		if(channel.type !== "text") {
			return error(message.channel, "Podany kanał nie jest kanałem tekstowym!")
		}
		const clientmember = message.guild.members.cache.get(client.user.id);
		if (channel.permissionsFor(clientmember).has('VIEW_CHANNEL') === false){
			return error(message.channel, "Bot nie posiada permisji do wyswietlania podanego kanalu!")
		}
		if (channel.permissionsFor(clientmember).has('SEND_MESSAGES') === false){
			return error(message.channel, "Bot nie posiada permisji do wysylania na podanym kanale!")
		}
		const currentChannel = await getChannel(message.guild.id);
		if(!currentChannel) {
			adsdb.prepare("INSERT INTO ads (guildId, adsChannel) VALUES (?, ?)").run(message.guild.id, channel.id);
		} else {
			adsdb.prepare("UPDATE ads SET adsChannel = ? WHERE guildId = ?").run(channel.id, message.guild.id);
		}
		const embed = new MessageEmbed()
			.setAuthor("Pomyślnie ustawiono!", "https://cdn.discordapp.com/emojis/760568194963341312.gif?v=1")
			.setDescription(`Pomyślnie ustawiono kanał na ${channel}`)
			.setColor("2EFF00")
		message.channel.send(embed)

	}
}
