const {MessageEmbed} = require("discord.js")
module.exports = {
	name: "link",
	aliases: ["linki"],
	run: async (client, message, args) => {
		const embed = new MessageEmbed()
			.setAuthor("Linki")
			.addField("Link do dodania bota", "[Kliknij tutaj](https://discord.com/api/oauth2/authorize?client_id=764573163605459005&permissions=8&scope=bot)")
			.addField("Link do serwera support", "[Kliknij tutaj](https://discord.gg/2FZwfqZ5dF)")
			.setColor("#000001")
		message.channel.send(embed)
	}
}
